const express = require("express");
const app = express();
const handlebars = require("express-handlebars");
const bodyParser = require("body-parser")
const moment = require('moment')
const Contato = require("./models/Contato")


app.engine('handlebars', handlebars({
    defaultLayout: 'main',
    helpers: {
        formatDate: (date) => {
            return moment(date).format('DD/MM/YYYY')
        }
    }
}))
app.set('view engine', 'handlebars')

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

//Rotas
app.get('/', function (req, res) {
    res.render('cad-contato');
});

app.get('/contato', function (req, res) {
    Contato.findAll({ order: [['id', 'DESC']] }).then(function (contatos) {
        res.render('contato', { contatos: contatos });
    })

});

app.get('/cad-contato', function (req, res) {
    res.render('cad-contato');
});

app.post('/add-contato', function (req, res) {
    Contato.create({
        nome: req.body.nome,
        Telefone: req.body.Telefone,
        Email: req.body.Email,
        cpf: req.body.cpf,
        endereco: req.body.endereco
    }).then(function () {
        res.redirect('/contato');
    }).catch(function (erro) {
        res.send("Erro: Contato não foi cadastrado com sucesso!" + erro);
    });
});


app.get('/visualizar-contato', function (req, res) {
    Contato.findAll().then(function () {
        res.redirect('/contato')
        //res.send("Pagamento cadastro com sucesso!")
    }).catch(function (erro) {
        res.send("Erro: Contato não foi cadastrado com sucesso!" + erro)
    })
    //res.send("Nome: " + req.body.nome + "<br>Valor: " + req.body.valor + "<br>") 
})
app.get('/del-contato/:id', function(req, res){
    Contato.destroy({
        where: {'id': req.params.id}
    }).then(function(){
        res.redirect('/contato');
        /*res.send("Pagamento apagado com sucesso!");*/
    }).catch(function(erro){
        res.send("Contato não apagado com sucesso!");
    })
});
console.log('Rodando....')

app.listen(8080);