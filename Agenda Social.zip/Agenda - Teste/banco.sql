CREATE DATABASE IF NOT EXISTS cadastro;

USE cadastro;

ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'root';

CREATE TABLE IF NOT EXISTS `contatos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
   `nome` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
   `Telefone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
   `Email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,  
   `createdAt` datetime NOT NULL,
   `updatedAt` datetime NOT NULL,
   PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


INSERT INTO `contatos` (`id`, `nome`, `Telefone`,`Email`,`createdAt`, `updatedAt`) VALUES
(2, 'vag', '(85)998672545','vagner_o_melhor@gmail.com', '2019-06-05 15:03:53', '2019-05-01 15:03:53');
COMMIT;
INSERT INTO `contatos` (`id`, `nome`, `Telefone`,`Email`,`createdAt`, `updatedAt`) VALUES
(3, 'Luan', '(85)99748548','luandosteclados@gmail.com', '2019-06-05 10:04:23', '2022-08-06 17:20:13');
COMMIT;
Select *
From contatos;
ALTER TABLE `contatos`
ADD COLUMN `cpf` VARCHAR(15) COLLATE utf8_unicode_ci DEFAULT NULL,
ADD COLUMN `endereco` VARCHAR(255) COLLATE utf8_unicode_ci DEFAULT NULL;