const { sequelize } = require('./db');  // Corrigindo a importação
const { DataTypes } = require('sequelize');  // Importando DataTypes

const Contato = sequelize.define('contatos', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    Telefone: {
        type: DataTypes.STRING,
        allowNull: false
    },
    Email: {
        type: DataTypes.STRING,
        allowNull: false
    },
    cpf: {
        type: DataTypes.STRING,
        allowNull: true
    },
    endereco: {
        type: DataTypes.STRING,
        allowNull: true
    }
}, {
    timestamps: true // Habilita os campos createdAt e updatedAt
});

module.exports = Contato;
